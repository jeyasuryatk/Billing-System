var app = angular.module('crudApp', []);

app.controller('crudController', function ($scope, $http) {
  $scope.users = [];
  $scope.user = {};
  $scope.isEditing = false;

  // Fetch users
  $scope.fetchUsers = function () {
    $http.get('http://localhost:3000/users').then(function (response) {
      $scope.users = response.data;
    });
  };

  // Add or Update user
  $scope.handleSubmit = function () {
    if ($scope.isEditing) {
      $scope.updateUser();
    } else {
      $scope.addUser();
    }
  };

  // Add User
  $scope.addUser = function () {
    $http.post('http://localhost:3000/users', $scope.user).then(function (response) {
      alert('User added!');
      $scope.fetchUsers();
      $scope.user = {}; // Reset form after submit
    }).catch(function (error) {
      console.error('Error adding user:', error);
      alert('Error adding user!');
    });
  };

  // Update User
  $scope.updateUser = function () {
    $http.put(`http://localhost:3000/users/${$scope.user.id}`, $scope.user).then(function () {
      alert('User updated!');
      $scope.fetchUsers();
      $scope.user = {};  // Reset form
      $scope.isEditing = false;  // Reset edit mode
    }).catch(function (error) {
      console.error('Error updating user:', error);
      alert('Error updating user!');
    });
  };

  // Edit user
  $scope.editUser = function (user) {
    $scope.user = angular.copy(user);  // Make a copy to preserve the original object
    $scope.isEditing = true;  // Enable edit mode
  };

  // Delete user
  $scope.deleteUser = function (id) {
    if (confirm('Are you sure you want to delete this user?')) {
      $http.delete(`http://localhost:3000/users/${id}`).then(function () {
        alert('User deleted!');
        $scope.fetchUsers();
      }).catch(function (error) {
        console.error('Error deleting user:', error);
        alert('Error deleting user!');
      });
    }
  };

  // Initialize users
  $scope.fetchUsers();
});

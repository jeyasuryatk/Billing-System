package com.example.hpuser.practice

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

import android.media.MediaPlayer

import android.widget.Button
import android.widget.ImageView


class Songs : AppCompatActivity() {
    private lateinit var mediaPlayer: MediaPlayer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_songs)

        val playButton: Button = findViewById(R.id.playButton)
        val stopButton: Button = findViewById(R.id.stopButton)
        val imageView: ImageView = findViewById(R.id.imageView)

        // Set an image to ImageView
        imageView.setImageResource(R.drawable.ic_launcher_background)

        // Initialize MediaPlayer with an audio file from res/raw
        mediaPlayer = MediaPlayer.create(this, R.raw.songs)

        playButton.setOnClickListener {
            if (!mediaPlayer.isPlaying) {
                mediaPlayer.start()
            }
        }

        stopButton.setOnClickListener {
            if (mediaPlayer.isPlaying) {
                mediaPlayer.pause()
                mediaPlayer.seekTo(0)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        mediaPlayer.release()
    }
}

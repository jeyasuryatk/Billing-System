package com.example.hpuser.practice

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle


import android.content.Intent
import android.view.*
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.Toast
import androidx.appcompat.widget.Toolbar

class OnlineStoreActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_online_store)

        val toolbar: Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

        val items = listOf("Dhoties", "Party Wear", "Model Wear", "Formal")
        val imageResources = listOf(
            R.drawable.hello,
            R.drawable.hello,
            R.drawable.hello,
            R.drawable.hello
        )

        val containerLayout = findViewById<LinearLayout>(R.id.containerLayout)

        for (i in items.indices) {
            val imageButton = ImageButton(this)
            imageButton.setImageResource(imageResources[i])
            imageButton.contentDescription = items[i]
            imageButton.scaleType = android.widget.ImageView.ScaleType.CENTER_CROP

            val layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                400
            )
            layoutParams.setMargins(16, 16, 16, 16)
            imageButton.layoutParams = layoutParams

            imageButton.setOnClickListener {
                showPopupMenu(it, items[i])
            }
            registerForContextMenu(imageButton)
            containerLayout.addView(imageButton)
        }
    }

    // Option Menu
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.option_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.settings -> {
                val intent = Intent(this, MainActivity2::class.java)
                startActivity(intent)
                true
            }
            R.id.profile -> {
                val intent = Intent(this, Sms::class.java)
                startActivity(intent)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    // Context Menu
    override fun onCreateContextMenu(menu: ContextMenu?, v: View?, menuInfo: ContextMenu.ContextMenuInfo?) {
        super.onCreateContextMenu(menu, v, menuInfo)
        menuInflater.inflate(R.menu.context, menu)
    }

    override fun onContextItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.add_to_cart -> {
                Toast.makeText(this, "this is context", Toast.LENGTH_SHORT).show()
                true
            }
            R.id.view_details -> {
                Toast.makeText(this, "Context", Toast.LENGTH_SHORT).show()
                true
            }
            else -> super.onContextItemSelected(item)
        }
    }

    // Popup Menu
    private fun showPopupMenu(view: View, itemName: String) {
        val popupMenu = PopupMenu(this, view)
        popupMenu.menuInflater.inflate(R.menu.popup, popupMenu.menu)
        popupMenu.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.add_to_cart_popup -> {
                    Toast.makeText(this, "Added to cart", Toast.LENGTH_SHORT).show()
                    true
                }
                R.id.view_details_popup -> {
                    Toast.makeText(this, "Viewing $itemName details", Toast.LENGTH_SHORT).show()
                    true
                }
                else -> false
            }
        }
        popupMenu.show()
    }
}

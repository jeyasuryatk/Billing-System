package com.example.hpuser.practice

import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.core.app.ActivityCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices


class Loc : AppCompatActivity() {
    //variable declarations
    lateinit var locationProvideClient: FusedLocationProviderClient
    lateinit var showLocation: Button
    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_loc)
        //creating fused location provider object
        locationProvideClient = LocationServices.getFusedLocationProviderClient(this)
        //binding my button to the variable
        showLocation = findViewById(R.id.show_my_location)
        //applying onClick Listener on the button
        showLocation.setOnClickListener{
            //calling the method to fetch your location
            getYourCurrentLocation()
        }
    }
    private fun getYourCurrentLocation()
    {
        //Checking if location permissions are provided
        if(ActivityCompat.checkSelfPermission(this,
                android.Manifest.permission.ACCESS_FINE_LOCATION) !=
            PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(this,
                android.Manifest.permission.ACCESS_COARSE_LOCATION) !=
            PackageManager.PERMISSION_GRANTED)
        {
            //Requesting permission to access location
            ActivityCompat.requestPermissions(
                this,
                arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION),
                909)
            return
        }
        //fetching your last known location
        val task = locationProvideClient.lastLocation
        task.addOnSuccessListener {
            if(it!=null)
            {
                //if the fetch is successful, then display the latitude and the longitude
                Toast.makeText(this,
                    "Latitude : ${it.latitude} \n Longitude: ${it.longitude}",
                    Toast.LENGTH_LONG).show()
            }
            else
            {
                Toast.makeText(this,
                    "Your location can't be displayed",
                    Toast.LENGTH_LONG).show()
            }
        }
    }
}




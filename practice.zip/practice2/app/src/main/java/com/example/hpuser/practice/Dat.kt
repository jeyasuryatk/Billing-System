Progressbar
private lateinit var showProgressBtn: Button
private lateinit var progressBar: ProgressBar
private val handler = Handler(Looper.getMainLooper())


showProgressBtn = findViewById(R.id.button)
progressBar = findViewById(R.id.progressBar)

showProgressBtn.setOnClickListener {
    incrementProgress()
}
}

private fun incrementProgress() {
    Thread {
        for (i in 1..100) {
            Thread.sleep(50)
            handler.post {
                progressBar.progress = i
            }
        }
    }.start()















    DatePicker
    textShown = findViewById(R.id.new1)
    dateNeed = findViewById(R.id.calenview)

    dateNeed.setOnDateChangeListener { _, year, month, dayOfMonth ->
        showDatePicker(year, month, dayOfMonth)
    }
}

private fun showDatePicker(year: Int, month: Int, day: Int) {
    val datePickerDialog = DatePickerDialog(this, { _, selectedYear, selectedMonth, selectedDay ->
        textShown.text = "Date: $selectedDay/${selectedMonth + 1}/$selectedYear"
    }, year, month, day)

    datePickerDialog.show()
}












Alert Dialog

val btnShowDialog: Button = findViewById(R.id.btnShowDialog)

btnShowDialog.setOnClickListener {
    showAlertDialog()
}
}

private fun showAlertDialog() {
    val builder = AlertDialog.Builder(this)
    builder.setTitle("Alert")
        .setMessage("This is a simple alert dialog.")
        .setPositiveButton("OK") { dialog, _ ->
            dialog.dismiss()
        }
        .setNegativeButton("Cancel") { dialog, _ ->
            dialog.dismiss()
        }
        .show() 


/////
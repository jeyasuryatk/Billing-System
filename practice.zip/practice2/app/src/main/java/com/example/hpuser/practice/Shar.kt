package com.example.hpuser.practice

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle




import android.content.Context

import android.widget.Button
import android.widget.EditText
import android.widget.TextView


class Shar : AppCompatActivity() {

    private lateinit var editText: EditText
    private lateinit var btnSave: Button
    private lateinit var textView: TextView
    private val PREFS_NAME = "MyPrefs"
    private val KEY_NAME = "username"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_shar)

        editText = findViewById(R.id.editText)
        btnSave = findViewById(R.id.btnSave)
        textView = findViewById(R.id.textView)

        val sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

        // Load saved name when app starts
        val savedName = sharedPreferences.getString(KEY_NAME, "No name saved")
        textView.text = "Saved Name: $savedName"

        btnSave.setOnClickListener {
            val name = editText.text.toString()
            sharedPreferences.edit().putString(KEY_NAME, name).apply()
            textView.text = "Saved Name: $name"
        }
    }
}

package com.example.hpuser.practice

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle



import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.graphics.drawable.GradientDrawable

import android.widget.ImageView
import android.widget.TextView


class Settings : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        val titleTextView = findViewById<TextView>(R.id.app_title)

        // Zoom in animation
        val scaleUpX = ObjectAnimator.ofFloat(titleTextView, "scaleX", 1.0f, 1.2f)
        val scaleUpY = ObjectAnimator.ofFloat(titleTextView, "scaleY", 1.0f, 1.2f)

        // Zoom out animation
        val scaleDownX = ObjectAnimator.ofFloat(titleTextView, "scaleX", 1.2f, 1.0f)
        val scaleDownY = ObjectAnimator.ofFloat(titleTextView, "scaleY", 1.2f, 1.0f)

        // Animation duration
        scaleUpX.duration = 100
        scaleUpY.duration = 100
        scaleDownX.duration = 100
        scaleDownY.duration = 100

        // Combine the animations
        val animatorSet = AnimatorSet()
        animatorSet.play(scaleUpX).with(scaleUpY)
        animatorSet.play(scaleDownX).after(scaleUpX)
        animatorSet.play(scaleDownY).after(scaleUpY)

        // Repeat animation in a loop
        animatorSet.addListener(object : android.animation.Animator.AnimatorListener {
            override fun onAnimationEnd(animation: android.animation.Animator) {
                animatorSet.start() // Restart the animation loop
            }
            override fun onAnimationStart(animation: android.animation.Animator) {}
            override fun onAnimationCancel(animation: android.animation.Animator) {}
            override fun onAnimationRepeat(animation: android.animation.Animator) {}
        })

        animatorSet.start()



        // Create a circle and rectangle programmatically
        val circleShape = GradientDrawable()
        circleShape.shape = GradientDrawable.OVAL
        circleShape.setColor(resources.getColor(android.R.color.holo_blue_light))
        circleShape.setSize(200, 200)

        val rectangleShape = GradientDrawable()
        rectangleShape.shape = GradientDrawable.RECTANGLE
        rectangleShape.setColor(resources.getColor(android.R.color.holo_green_light))
        rectangleShape.cornerRadius = 16f
        rectangleShape.setSize(400, 200)

        // Apply these shapes to background views (if applicable)
        // You can add additional graphical or animation logic as needed

        // Blinking Bulb Animation
        val blinkingBulb = findViewById<ImageView>(R.id.blinkingBulb)
        val blinkAnimation = ObjectAnimator.ofFloat(blinkingBulb, "alpha", 1f, 0f)
        blinkAnimation.duration = 500 // Half a second for each blink
        blinkAnimation.repeatMode = ObjectAnimator.REVERSE // Reverse the animation for blink effect
        blinkAnimation.repeatCount = ObjectAnimator.INFINITE // Repeat the animation infinitely
        blinkAnimation.start()
    }
}
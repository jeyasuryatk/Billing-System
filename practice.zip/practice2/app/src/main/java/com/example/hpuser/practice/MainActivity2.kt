package com.example.hpuser.practice

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

import android.bluetooth.BluetoothAdapter
import android.content.Intent

import android.widget.Button
import android.widget.TextView


class MainActivity2 : AppCompatActivity() {

    private val bluetoothAdapter: BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        val bluetoothStatusText = findViewById<TextView>(R.id.bluetoothStatusText)
        val toggleBluetoothButton = findViewById<Button>(R.id.toggleBluetoothButton)

        // Function to update Bluetooth status
        fun updateBluetoothStatus() {
            bluetoothStatusText.text = when {
                bluetoothAdapter == null -> "Bluetooth not supported"
                bluetoothAdapter.isEnabled -> "Bluetooth is ON"
                else -> "Bluetooth is OFF"
            }
        }

        // Set initial Bluetooth status
        updateBluetoothStatus()

        // Toggle Bluetooth when button is clicked
        toggleBluetoothButton.setOnClickListener {
            if (bluetoothAdapter != null) {
                if (bluetoothAdapter.isEnabled) {
                    bluetoothAdapter.disable()
                } else {
                    val enableBtIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
                    startActivity(enableBtIntent)
                }
            }
            updateBluetoothStatus()
        }
    }
}


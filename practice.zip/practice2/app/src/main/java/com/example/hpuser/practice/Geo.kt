package com.example.hpuser.practice

import android.location.Geocoder
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import java.util.Locale



class Geo: AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_geo)

        val textView: TextView = findViewById(R.id.textView)

        val latitude =   9.9129 // Example: San Francisco
        val longitude = 78.1477



        val address = getAddressFromLatLng(latitude, longitude)
        textView.text = address ?: "Address not found"
    }

    private fun getAddressFromLatLng(lat: Double, lng: Double): String? {
        return try {
            val geocoder = Geocoder(this, Locale.getDefault())
            val addresses = geocoder.getFromLocation(lat, lng, 1)
            if (!addresses.isNullOrEmpty()) {
                val address = addresses[0]
                "${address.getAddressLine(0)}, ${address.locality}, ${address.countryName}"
            } else {
                "No address found"
            }
        } catch (e: Exception) {
            e.printStackTrace()
            "Error fetching address"
        }
    }
}



package com.example.hpuser.practice

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.content.Context
import android.net.wifi.WifiManager

import android.widget.Button
import android.widget.TextView


class MainActivity3 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)

        val wifiStatusText = findViewById<TextView>(R.id.wifiStatusText)
        val toggleWifiButton = findViewById<Button>(R.id.toggleWifiButton)
        val wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager

        // Function to update Wi-Fi status
        fun updateWifiStatus() {
            wifiStatusText.text = if (wifiManager.isWifiEnabled) "Wi-Fi is ON" else "Wi-Fi is OFF"
        }

        // Set initial Wi-Fi status
        updateWifiStatus()

        // Toggle Wi-Fi when button is clicked
        toggleWifiButton.setOnClickListener {
            wifiManager.isWifiEnabled = !wifiManager.isWifiEnabled
            updateWifiStatus()
        }
    }
}


package com.example.taxi_application

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Address
import android.location.Geocoder
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.ContextMenu
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.firebase.database.FirebaseDatabase
import java.io.IOException
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    lateinit var driverListView: ListView
    lateinit var arrayAdaptor: ArrayAdapter<String>
    private var driverArray: Array<String> = arrayOf("Ram", "Kumar", "Lakshman")
    private val CHANNEL_ID = "MyNotifications"
    private var notificationId = 1
    private val CAMERA_REQUEST_CODE = 1002
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        ActivityCompat.requestPermissions(this, arrayOf(
            Manifest.permission.CAMERA,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_WIFI_STATE,
            Manifest.permission.CHANGE_WIFI_STATE,
            Manifest.permission.BLUETOOTH_CONNECT,
            Manifest.permission.BLUETOOTH_ADMIN,
            Manifest.permission.BLUETOOTH,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.ACCESS_BACKGROUND_LOCATION,
            Manifest.permission.POST_NOTIFICATIONS,
        ), 1001)
        fetchFromSQLite()
        driverListView = findViewById(R.id.driver_list)
        registerForContextMenu(driverListView)
        arrayAdaptor = ArrayAdapter(this, android.R.layout.simple_list_item_1, driverArray)
        driverListView.adapter = arrayAdaptor
        createNotificationChannel()
        val addressFromPref = fetchFromSharedPreferences()
        Toast.makeText(this, "From SharedPreferences: $addressFromPref", Toast.LENGTH_SHORT).show()

        val btnTakePhoto: Button = findViewById(R.id.btnTakePhoto)
        val btnTurnOnWiFi: Button = findViewById(R.id.btnTurnOnWiFi)
        val btnTurnOnBluetooth: Button = findViewById(R.id.btnTurnOnBluetooth)

        btnTakePhoto.setOnClickListener {
            openCamera()
        }

        btnTurnOnWiFi.setOnClickListener {
            turnOnWiFi()
        }

        btnTurnOnBluetooth.setOnClickListener {
            turnOnBluetooth()
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "Driver Notification"
            val descriptionText = "Notification to book driver"
            val importance = NotificationManager.IMPORTANCE_DEFAULT
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
            }
            val notificationManager: NotificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    override fun onCreateContextMenu(
        menu: ContextMenu?,
        v: View?,
        menuInfo: ContextMenu.ContextMenuInfo?
    ) {
        menuInflater.inflate(R.menu.context_menu, menu)
        super.onCreateContextMenu(menu, v, menuInfo)
    }

    override fun onContextItemSelected(item: MenuItem): Boolean {
        val info = item.menuInfo as AdapterView.AdapterContextMenuInfo
        val position = info.position
        val selectedDriverName = driverArray[position]
        when (item.itemId) {
            R.id.book_driver -> {
                val builder = androidx.appcompat.app.AlertDialog.Builder(this)
                builder.setTitle("Confirm Booking")
                builder.setMessage("Do you want to book driver $selectedDriverName?")
                builder.setPositiveButton("Yes") { dialog, _ ->
                    Toast.makeText(this, "Booking Driver $selectedDriverName", Toast.LENGTH_SHORT)
                        .show()
                    sendDriverBookedNotification(selectedDriverName)
                    dialog.dismiss()
                }
                builder.setNegativeButton("No") { dialog, _ ->
                    dialog.dismiss()
                }
                val alertDialog = builder.create()
                alertDialog.show()
                return true
            }

            (R.id.cancel_booking) -> {
                Toast.makeText(this, "Cancel Booking", Toast.LENGTH_SHORT).show()
                return true
            }
        }
        return super.onContextItemSelected(item)
    }

    private fun sendDriverBookedNotification(driverName: String) {
        val intent = Intent(this, MainActivity::class.java)
        val pendingIntent: PendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE)

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("Driver Booked")
            .setContentText("Driver $driverName has been booked.")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)

        with(NotificationManagerCompat.from(this)) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS),1)
            }
            if (ActivityCompat.checkSelfPermission(
                    this@MainActivity,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                return
            }
            notify(notificationId++, builder.build())
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.options_menu, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            (R.id.get_location) -> {
                fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1001)
                } else {
                    getUserLocation()
                }
            }
        }
        return super.onOptionsItemSelected(item)
    }
    private fun getUserLocation(){
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }
        fusedLocationClient.lastLocation.addOnSuccessListener { location ->
            if (location != null) {
                val latitude = location.latitude
                val longitude = location.longitude
                getAddressFromLocation(latitude, longitude)
                Toast.makeText(this, "Get Location $latitude, $longitude", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun getAddressFromLocation(latitude: Double, longitude: Double) {
        val geocoder = Geocoder(this, Locale.getDefault())
        val addresses: List<Address>?

        try {
            addresses = geocoder.getFromLocation(latitude, longitude, 1)

            if (!addresses.isNullOrEmpty()) {
                val address = addresses[0].getAddressLine(0)
                saveToSharedPreferences(address)
                saveToSQLite(address)
                saveToFirebase(address)
                Toast.makeText(this, "Get Location $address", Toast.LENGTH_SHORT).show()
            }
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }

    private fun saveToSharedPreferences(address: String) {
        val sharedPref = getSharedPreferences("location_pref", Context.MODE_PRIVATE)
        with(sharedPref.edit()) {
            putString("user_address", address)
            apply()
        }
    }

    private fun saveToSQLite(address: String) {
        val dbHelper = LocationDatabaseHelper(this)
        dbHelper.insertAddress(address)
    }
    private fun saveToFirebase(address: String) {
        val database = FirebaseDatabase.getInstance()
        val ref = database.getReference("users_location")
        val id = ref.push().key
        if (id != null) {
            ref.child(id).setValue(address)
        }
    }
    private fun fetchFromSharedPreferences(): String? {
        val sharedPref = getSharedPreferences("location_pref", Context.MODE_PRIVATE)
        return sharedPref.getString("user_address", null)
    }

    private fun fetchFromSQLite() {
        val dbHelper = LocationDatabaseHelper(this)
        val addresses = dbHelper.getAllAddresses()
        addresses.forEach { address ->
            Toast.makeText(this, "From SQLite: $address", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openCamera() {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        startActivityForResult(intent, CAMERA_REQUEST_CODE)
    }

    private fun turnOnWiFi() {
        val wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        if (!wifiManager.isWifiEnabled) {
            wifiManager.isWifiEnabled = true
            Toast.makeText(this, "WiFi turned ON", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "WiFi is already ON", Toast.LENGTH_SHORT).show()
        }
    }

    private fun turnOnBluetooth() {
        val bluetoothAdapter: BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()
        if (bluetoothAdapter == null) {
            Toast.makeText(this, "Bluetooth not supported", Toast.LENGTH_SHORT).show()
        } else {
            if (!bluetoothAdapter.isEnabled) {
                val enableBtIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
                if (ActivityCompat.checkSelfPermission(
                        this,
                        Manifest.permission.BLUETOOTH_CONNECT
                    ) != PackageManager.PERMISSION_GRANTED
                ) {
                    return
                }
                startActivity(enableBtIntent)
            } else {
                Toast.makeText(this, "Bluetooth already ON", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun playAudio() {
    mediaPlayer = MediaPlayer.create(this, R.raw.sample_audio)  // MP3 inside res/raw folder
    mediaPlayer?.start()
}
    // To stop:
    fun stopAudio() {
        mediaPlayer?.stop()
        mediaPlayer?.release()
    }

    fun playVideo() {
        val videoView = findViewById<VideoView>(R.id.myVideoView)
        val videoUri = Uri.parse("android.resource://" + packageName + "/" + R.raw.sample_video)
        videoView.setVideoURI(videoUri)
        val mediaController = MediaController(this)
        mediaController.setAnchorView(videoView)
        videoView.setMediaController(mediaController)
        videoView.start()
    }

}

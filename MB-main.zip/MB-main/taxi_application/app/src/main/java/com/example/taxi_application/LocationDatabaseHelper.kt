package com.example.taxi_application

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class LocationDatabaseHelper(context: Context) : SQLiteOpenHelper(context, "locationDB", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE LocationTable(id INTEGER PRIMARY KEY AUTOINCREMENT, address TEXT)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS LocationTable")
        onCreate(db)
    }

    fun insertAddress(address: String) {
        val db = writableDatabase
        val values = ContentValues()
        values.put("address", address)
        db.insert("LocationTable", null, values)
        db.close()
    }
    fun getAllAddresses(): List<String> {
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT address FROM LocationTable", null)
        val addressList = mutableListOf<String>()

        if (cursor.moveToFirst()) {
            do {
                val address = cursor.getString(cursor.getColumnIndexOrThrow("address"))
                addressList.add(address)
            } while (cursor.moveToNext())
        }
        cursor.close()
        db.close()

        return addressList
    }

}

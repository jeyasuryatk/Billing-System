package com.example.terminalpractise

import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.view.animation.AlphaAnimation
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import android.widget.VideoView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var videoview:VideoView
    private lateinit var playAudio: ImageButton
    private lateinit var animate:TextView
    private var mediaPlayer: MediaPlayer?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val implicit_button=findViewById<Button>(R.id.implicit_intent)
        val layout_but=findViewById<Button>(R.id.open_layout)

        implicit_button.setOnClickListener{
            val web:Uri= Uri.parse("https://www.google.com")
            val intent = Intent(Intent.ACTION_VIEW,web)
            startActivity(intent)
        }

        layout_but.setOnClickListener{
            val intent1 = Intent(this,LayoutsActivity::class.java)
            startActivity(intent1)
        }

        videoview = findViewById(R.id.videoView)
        playAudio = findViewById(R.id.playAudioButton)
        animate = findViewById(R.id.animatedText)

        val videoUri = Uri.parse("android.resource://" + packageName + "/" + R.raw.sample_video)
        videoview.setVideoURI(videoUri)
        videoview.start()

        playAudio.setOnClickListener{
            if(mediaPlayer==null){
                mediaPlayer=MediaPlayer.create(this,R.raw.sample_video)
                mediaPlayer?.start()
            }
        }

        val animation = AlphaAnimation(0.0f,1.0f).apply{
            duration = 1000
            repeatCount = AlphaAnimation.INFINITE
            repeatMode = AlphaAnimation.REVERSE
        }
        animate.startAnimation(animation)

    }
    override fun onDestroy(){
        super.onDestroy()
        mediaPlayer?.release()
        mediaPlayer=null
    }
}


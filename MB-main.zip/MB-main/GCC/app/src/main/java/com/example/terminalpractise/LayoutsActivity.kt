package com.example.terminalpractise

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.TimePickerDialog
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorManager
import android.health.connect.datatypes.ExerciseRoute
import android.location.Location
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.ContextMenu
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.PopupMenu
import android.widget.Toast
import androidx.annotation.RequiresPermission
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import java.util.Calendar
import java.util.Locale
import android.location.Geocoder
import android.media.MediaRecorder
import android.net.wifi.WifiManager
import android.provider.MediaStore
import android.database.sqlite.SQLiteDatabase
import android.content.ContentValues
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class LayoutsActivity : AppCompatActivity() {

    private lateinit var sharedpref : SharedPreferences
    private lateinit var fusedclient: FusedLocationProviderClient
    private var date=""
    private var time=""
    private var address:String=""

    private var mediaRecorder: MediaRecorder?=null

    private val permissions = arrayOf(
        Manifest.permission.CAMERA,
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.CHANGE_WIFI_STATE,
        Manifest.permission.BLUETOOTH_CONNECT
    )

    private val REQUEST_PERMISSION_CODE = 100

    private lateinit var database: SQLiteDatabase

    @SuppressLint("ServiceCast")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_layouts)

        val btnpop=findViewById<Button>(R.id.btnpop)

        btnpop.setOnClickListener{
            val popmenu=PopupMenu(this,btnpop)
            popmenu.menuInflater.inflate(R.menu.popup_menu,popmenu.menu)
            popmenu.setOnMenuItemClickListener { item->
                when(item.itemId){
                    R.id.menu_share->{
                        Toast.makeText(this,"share clicked",Toast.LENGTH_SHORT).show()
                        true
                    }
                    R.id.menu_delete->{
                        Toast.makeText(this,"Delete CLicked",Toast.LENGTH_SHORT).show()
                        true
                    }
                    else->false
                }
            }
            popmenu.show()
        }

        val datebtn = findViewById<Button>(R.id.datepicker)
        val schedulted = findViewById<Button>(R.id.showSchedule)
        sharedpref=getSharedPreferences("myPref", Context.MODE_PRIVATE)

        datebtn.setOnClickListener{
            showDatePicker()
        }

        schedulted.setOnClickListener{
            val date=sharedpref.getString("date","no date found")
            val time=sharedpref.getString("time","no time found")
            Toast.makeText(this,"Saved Schedule:\n$date at $time",Toast.LENGTH_LONG).show()
        }

        fusedclient= LocationServices.getFusedLocationProviderClient(this)

        val btnloc=findViewById<Button>(R.id.btnGetLocation)
        val btnsms=findViewById<Button>(R.id.btnShareSMS)
        val btnwhat=findViewById<Button>(R.id.btnShareWhatsApp)

        btnloc.setOnClickListener{
            getLocation()
        }
        btnsms.setOnClickListener{
            if(address.isNotEmpty()){
                val intent1 = Intent(Intent.ACTION_VIEW)
                intent1.data = Uri.parse("smsto:7845540089")
                intent1.putExtra("address",address)
                startActivity(intent1)
            }
            else{
                Toast.makeText(this,"Location not available",Toast.LENGTH_SHORT).show()
            }
        }

        btnwhat.setOnClickListener{
            if(address.isNotEmpty()){
                val intent2=Intent()
                intent2.action=Intent.ACTION_SEND
                intent2.putExtra(Intent.EXTRA_TEXT,"Location: $address")
                intent2.type="text/plain"
                intent2.setPackage("com.whatsapp")
                try{
                startActivity(intent2)}
                catch(e:Exception){
                    Toast.makeText(this,"WhatsApp not installed",Toast.LENGTH_SHORT).show()
                }
            }
            else{
                Toast.makeText(this,"Location not available",Toast.LENGTH_SHORT).show()
            }
        }

        ActivityCompat.requestPermissions(this,permissions,REQUEST_PERMISSION_CODE)

        val cameraBtn = findViewById<Button>(R.id.btnCamera)
        val micBtn = findViewById<Button>(R.id.btnMic)
        val wifiBtn = findViewById<Button>(R.id.btnWifi)
        val bluetoothBtn = findViewById<Button>(R.id.btnBluetooth)
        val sensorBtn = findViewById<Button>(R.id.btnSensor)

        cameraBtn.setOnClickListener{
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                startActivity(intent)
            } else {
                Toast.makeText(this, "Camera permission required", Toast.LENGTH_SHORT).show()
            }
        }

        micBtn.setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                mediaRecorder = MediaRecorder().apply {
                    setAudioSource(MediaRecorder.AudioSource.MIC)
                    setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP)
                    setOutputFile("${externalCacheDir?.absolutePath}/recording.3gp")
                    setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB)
                    prepare()
                    start()
                }
                Toast.makeText(this, "Recording started...", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Microphone permission required", Toast.LENGTH_SHORT).show()
            }
        }

        wifiBtn.setOnClickListener {
            val wifiManager = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
            wifiManager.isWifiEnabled = !wifiManager.isWifiEnabled
            Toast.makeText(this, "WiFi toggled", Toast.LENGTH_SHORT).show()
        }

        bluetoothBtn.setOnClickListener {
            val bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
            if (bluetoothAdapter != null && !bluetoothAdapter.isEnabled) {
                val enableBtIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
                startActivity(enableBtIntent)
            } else {
                Toast.makeText(this, "Bluetooth already enabled or not available", Toast.LENGTH_SHORT).show()
            }
        }


        // SQLite DB setup
        database = openOrCreateDatabase("SchedulesDB", MODE_PRIVATE, null)
        database.execSQL("CREATE TABLE IF NOT EXISTS schedules (id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT, time TEXT)")
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.options_menu,menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            R.id.menu_settings->{
                Toast.makeText(this,"Settings clicked", Toast.LENGTH_SHORT).show()
                return true
            }
            R.id.menu_help->{
                Toast.makeText(this,"Help clicked",Toast.LENGTH_SHORT).show()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }
    override fun onCreateContextMenu(menu: ContextMenu?, v: View?, menuInfo:ContextMenu.ContextMenuInfo?){
        super.onCreateContextMenu(menu,v,menuInfo)
        menuInflater.inflate(R.menu.context_menu,menu)
    }
    override fun onContextItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.menu_edit -> {
                Toast.makeText(this, "Edit clicked", Toast.LENGTH_SHORT).show()
                true
            }
            R.id.menu_delete -> {
                Toast.makeText(this, "Delete clicked", Toast.LENGTH_SHORT).show()
                true
            }
            else -> super.onContextItemSelected(item)
        }
    }
    private fun showDatePicker()
    {
        val calendar = Calendar.getInstance()

        val datePickerDialog = DatePickerDialog(this, { _, year, month, dayOfMonth ->
            date = "$dayOfMonth/${month+1}/$year"
            openTimePicker()
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH))

        datePickerDialog.show()
    }
    private fun openTimePicker(){
        val calendar = Calendar.getInstance()

        val timePickerDialog = TimePickerDialog(this, { _, hourOfDay, minute ->
            time = String.format("%02d:%02d", hourOfDay, minute)
            showAlertDialog()
        }, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), true)

        timePickerDialog.show()
    }
    private fun showAlertDialog(){
        AlertDialog.Builder(this)
            .setTitle("Confirm")
            .setMessage("Save schedule for $date at ${time}?")
            .setPositiveButton("Yes") { _, _ ->
                saveSchedule()
            }
            .setNegativeButton("No", null)
            .show()
    }
    private fun saveSchedule(){
        val editor = sharedpref.edit()
        editor.putString("date", date)
        editor.putString("time", time)
        editor.apply()
        Toast.makeText(this, "Schedule saved", Toast.LENGTH_SHORT).show()

        // Save to SQLite
        val values = ContentValues().apply {
            put("date", date)
            put("time", time)
        }
        database.insert("schedules", null, values)

        showNotification()
    }
    private fun showNotification(){
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "schedule_channel",
                "Schedule Channel",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            notificationManager.createNotificationChannel(channel)
        }

        val builder = NotificationCompat.Builder(this, "schedule_channel")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Schedule Saved!")
            .setContentText("Scheduled on $date at $time")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)

        notificationManager.notify(2, builder.build())
    }

    private fun getLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            == PackageManager.PERMISSION_GRANTED
        ) {
            fusedclient.lastLocation
                .addOnSuccessListener { location: Location? ->
                    location?.let {
                        getAddressFromLocation(it)
                    } ?: Toast.makeText(this, "Location not found", Toast.LENGTH_SHORT).show()
                }
        }
    }
    private fun getAddressFromLocation(location: Location) {
        val geocoder = Geocoder(this, Locale.getDefault())
        val addresses = geocoder.getFromLocation(location.latitude, location.longitude, 1)
        if (!addresses.isNullOrEmpty()) {
            val address1 = addresses[0]
            address = "${address1.getAddressLine(0)}"
            Toast.makeText(this, "Location: $address", Toast.LENGTH_LONG).show()
        }
    }




}

